# LeadZam UI/UX Audit — Working Draft

**Candidate:** Ruchi Yadav  
**Role:** UI/UX & Frontend Intern  
**Product:** LeadZam  
**Status:** Draft requiring candidate verification

## Scope and evidence

The public LeadZam marketing website was reviewed at https://leadzam.com. It describes lead capture from Meta Ads, Google Ads, WhatsApp, website forms, manual entry and CSV; lead stages; call tracking; WhatsApp conversations; and campaign analytics. The public app entry point is https://app.leadzam.com.

The authenticated workspace was not inspected as part of this draft. Therefore, the findings below are **hypotheses to investigate**, not verified defects in the current application. Before submitting, personally explore the app with your own test workspace and dummy data, replace unsupported findings, and attach screenshots captured by you.

## Prioritized findings / hypotheses

### 1. Make the next lead action obvious
- **Area:** Lead list / lead detail / follow-up workflow (verify in app)
- **User goal:** Quickly identify which lead needs attention and what to do next.
- **Hypothesis:** If next follow-up information is not visible in the list, users may need to open multiple records or rely on memory.
- **Why it matters:** Delayed follow-up can reduce response rates and create avoidable manual work for sales teams.
- **Recommended direction:** Add a concise next-action / follow-up column or an actionable “Needs follow-up” view, with overdue and unscheduled states.
- **Priority:** High
- **Evidence to attach:** Screenshot of the real lead list and a real example of the current follow-up path. Do not use the prototype as evidence of a current defect.

### 2. Clarify the add-lead form and validation
- **Area:** Manual lead creation (verify in app)
- **User goal:** Capture a lead without guessing which fields are required.
- **Hypothesis:** If required fields and validation feedback are unclear, users may encounter avoidable form errors.
- **Why it matters:** Form friction slows down sales teams and can lead to incomplete records.
- **Recommended direction:** Group fields logically, mark required fields, validate inline, preserve entered data after an error, and show a success confirmation.
- **Priority:** High
- **Evidence to attach:** Screenshots of the actual form in default and validation-error states.

### 3. Improve search and filter discoverability
- **Area:** Lead directory (verify in app)
- **User goal:** Find a lead by name, company, source, or stage.
- **Hypothesis:** If search scope, active filters, or filter-reset behavior are hard to understand, users can believe a record is missing.
- **Why it matters:** Search is a frequent task in a CRM and should not require repeated navigation.
- **Recommended direction:** Keep search and filters together, show active filters, provide a clear reset action, and show a helpful empty-results state.
- **Priority:** High
- **Evidence to attach:** Screenshot showing the real search/filter controls and the result state after a search.

### 4. Make lead status and ownership scannable
- **Area:** Lead table / pipeline (verify in app)
- **User goal:** Understand who owns a lead and what stage it is in at a glance.
- **Hypothesis:** If status and owner are visually buried or represented inconsistently, users need extra time to scan records.
- **Why it matters:** Teams need clear accountability and fast handoffs.
- **Recommended direction:** Use consistent status labels, owner identity, predictable column alignment, and a direct way to update a stage.
- **Priority:** Medium
- **Evidence to attach:** Screenshot of the real lead table and a stage-change interaction if available.

### 5. Strengthen first-time-user guidance and empty states
- **Area:** Trial/signup and first app entry (verify in app)
- **User goal:** Understand the first useful action after creating a workspace.
- **Hypothesis:** If a new workspace opens without sample data or a clear setup path, new users may not know how to start capturing leads.
- **Why it matters:** Early confusion can prevent users from reaching the product's core value.
- **Recommended direction:** Provide a short setup checklist, explain the first action, and offer sample/demo data where appropriate.
- **Priority:** Medium
- **Evidence to attach:** Screenshot of the real first-run experience or an empty workspace.

## Selected improvement

**Lead directory with clearer discovery, add-lead validation, and lead-stage updates.**

This direction is small enough to implement as a frontend prototype while demonstrating product reasoning, interaction design, error/empty states, and responsive behavior.

## What is included in the prototype

- Search by name, company, email, and source
- Tabs for all leads, new leads, and leads needing follow-up
- Status and source filters with a reset action
- Add-lead modal with required-field and email validation
- Confirmation toast after creating a sample lead
- Lead details drawer with stage update
- Empty-results state
- Responsive layout

## Limitations and validation

This prototype uses fictional local data and is not connected to LeadZam's backend. It is a concept, not a claim that the current app has these exact problems. Before production, validate the hypotheses with real user observation, compare task completion times, check permission requirements, and confirm field/stage semantics with the product team.
