# Final submission checklist

Assignment due: **20 October 2026, EOD**  
Recipient: **helloteamvariance@gmail.com**

Before emailing:
- [ ] Run `npm install`
- [ ] Run `npm run dev` and click through all interactions
- [ ] Run `npm run build` and fix any errors
- [ ] Explore LeadZam yourself and replace draft audit hypotheses with verified observations
- [ ] Add your own screenshots of the real product
- [ ] Create a real Figma file from `docs/FIGMA-SPEC.md` and add the share URL
- [ ] Create a GitHub repository and push source code with several meaningful commits (do not fake history)
- [ ] Record a 3–5 minute walkthrough using `docs/DEMO-SCRIPT.md`
- [ ] Update README with your real Figma/GitHub/demo links
- [ ] Confirm all claims in AI Usage Notes are accurate

Email subject suggestion: `UI/UX & Frontend Intern Assignment — Ruchi Yadav`

Attach/share:
1. UX audit (PDF or Markdown/Google Doc)
2. Figma link
3. GitHub repository link
4. README and run instructions in repository
5. Demo video link/file
6. AI Usage Notes and limitations
