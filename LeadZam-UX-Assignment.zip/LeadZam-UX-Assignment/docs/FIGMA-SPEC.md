# Figma Redesign Specification

Use this as a build guide in Figma. It is not a Figma file or share link; create the frames in your own Figma account and paste the actual link into the final submission.

## Page 1 — Lead Directory (Desktop)
- Frame: 1440 × 1000, background #F7F8FC
- Left sidebar: 246 px, white, subtle border
- Top bar: 69 px
- Content max-width: 1450 px, 38 px horizontal padding
- Heading: “Leads” + helper text + Export / Add lead actions
- Four metric cards: Total leads, Needs follow-up, Qualified leads, Pipeline value
- Lead directory card with tabs, search, filters, table and pagination
- Main interaction: Add lead opens a modal; clicking a lead opens details drawer.

## Page 2 — Add Lead / Validation
Create two states of the same modal:
1. Default state with Lead name, Company, Email address, Lead source, Assign owner.
2. Error state where required name/email are missing or email format is invalid. Show inline form-level error and retain typed values.
3. Success can be shown as a toast after modal closes.

## Page 3 — Empty Search State
- Keep the search query visible.
- Show a small filter/search illustration or icon.
- Heading: “No leads match those filters”
- Support text: “Try another search or clear filters to see all leads.”
- Primary recovery action: “Clear filters”.

## Page 4 — Lead Details Drawer
- Right drawer, width 410 px
- Lead identity, company and status
- Contact information rows
- Editable status dropdown
- Next-action / follow-up summary
- “Log an activity” action

## Page 5 — Responsive (Mobile)
- Frame: 390 × 844
- Sidebar becomes an overlay drawer
- Metrics become 2 columns
- Search spans full width
- Table can scroll horizontally; core add-lead action remains accessible
- Modal fields stack vertically.

## Component inventory
- Button: primary / secondary / quiet
- Status pill: New / Contacted / Qualified / Won / Lost
- Metric card
- Lead avatar / owner avatar
- Search input
- Filter select
- Table row
- Modal
- Toast
- Empty state
- Details drawer

## Tokens
- Primary: #6856DF
- Ink: #20243A
- Muted text: #7C8299
- Background: #F7F8FC
- Border: #E9EBF3
- Success: #21885F
- Warning: #CF8A27
- Error: #C95C65
- Body font: DM Sans
- Display font: Manrope

## Prototype connections
- Add lead button → Add Lead modal
- Submit invalid form → Validation error
- Submit valid form → Close modal + success toast + new row at top
- Click lead → Details drawer
- Change status → Update status pill and show toast
- Search / filter → Update visible rows
- Clear filters → Reset search and filters
