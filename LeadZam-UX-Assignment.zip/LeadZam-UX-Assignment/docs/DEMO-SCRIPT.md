# 3–5 Minute Walkthrough Script

**Before recording:** Run `npm run dev`, open the prototype in your browser, and use your own recording tool. Do not claim a real production app issue unless you have personally verified it.

## 0:00–0:30 — Context
“Hi, I’m Ruchi. This is my LeadZam UI/UX and frontend assignment. I focused on a lead-directory workflow because lead discovery, qualification, and follow-up are core CRM tasks. The current findings in my audit are hypotheses until confirmed against the authenticated workspace.”

## 0:30–1:20 — Audit and prioritization
“Rather than redesigning the whole product, I prioritized issues that could affect frequent user tasks: making the next action clear, reducing friction in lead creation, improving search/filter recovery, making status and ownership scannable, and clarifying first-run guidance. I selected lead discovery and creation because the scope is high-value but still small enough to prototype.”

Show the audit and, after you have collected them, the actual LeadZam screenshots that support your findings.

## 1:20–2:15 — Proposed design
“Search and filters sit together. The lead table keeps source, status, owner, and created date visible. A new lead can be added through a focused modal. Required fields are clear, and invalid input produces feedback. A user can open a lead detail drawer to review information and change the stage without losing list context.”

Show the Figma frames and the connections between them.

## 2:15–3:45 — Working prototype
Demonstrate:
1. Search for a lead by name or company.
2. Open filters and filter by status/source.
3. Search for a nonexistent lead and show the empty state, then clear filters.
4. Click “Add lead”, submit invalid data, then add a valid sample lead.
5. Open a lead and change its status.
6. Export the visible rows to CSV.
7. Resize the browser to show responsive behavior.

## 3:45–4:30 — Technical choices and limitations
“The prototype uses React and TypeScript with local mock data; it does not connect to a backend. This let me demonstrate the key states without building a large CRM. If taking this to production, I would validate the workflow with sales users, check permissions and required fields with the product team, and measure time-to-find and add-lead completion.”

## 4:30–5:00 — AI usage
“I used ChatGPT to help structure the implementation and documentation. I reviewed and tested the interactions rather than treating generated code as final. I intentionally kept the scope to one workflow and used fictional data.”

**Important:** Adjust the AI statement so it accurately describes the tools you actually used and the checks you personally completed.
