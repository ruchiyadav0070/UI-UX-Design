# LeadZam UX Improvement — Lead Directory

A focused React + TypeScript prototype for a lead-management workflow, created for the Variance UI/UX & Frontend Intern take-home assignment.

> **Important integrity note:** This is an independent concept prototype using fictional data, not LeadZam's production UI or source code. The public marketing site was reviewed; authenticated app screens and any claims about problems inside the private app must be verified by the candidate before submission. Do not describe the prototype as an actual production fix.

## Problem hypothesis

Lead management is a high-frequency CRM task. A useful improvement direction is to make lead discovery and the next action clearer by combining:
- Search across lead name, company, email, and source
- Optional status/source filters with a visible reset path
- At-a-glance status, owner, source, and creation date
- A concise add-lead form with validation and confirmation
- A detail drawer to review contact information and update stage
- Empty results and mobile layout states

These are **design hypotheses** to validate against the real authenticated product. Update the audit after personally exploring LeadZam.

## Features

- Responsive desktop/tablet/mobile layout
- Fictional sample leads only
- Search, tabs, status/source filters, and reset filters
- Add lead modal with required-field and email validation
- Lead detail drawer with editable stage
- Toast feedback for interactions
- CSV export of currently filtered rows
- Accessible labels, dialog roles, status feedback, and keyboard focus styles
- No backend, no authentication, and no real customer data

## Run locally

Requirements: Node.js 18+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

Build and preview:

```bash
npm run build
npm run preview
```

## Project structure

```text
LeadZam-UX-Assignment/
├── public/
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   └── styles.css
├── docs/
│   ├── UX-AUDIT.md
│   ├── FIGMA-SPEC.md
│   └── DEMO-SCRIPT.md
├── index.html
├── package.json
├── tsconfig.app.json
├── tsconfig.json
└── vite.config.ts
```

## Design rationale

The selected direction prioritizes the lead directory because lead discovery and qualification are central CRM tasks. Search and filters sit together; the table keeps status, source, and owner visible; adding a lead uses a short form; and the details drawer lets a user update stage without losing list context.

### Deliberately out of scope

- Production API or database integration
- Authentication, roles, and real workspace data
- Real call, WhatsApp, or follow-up scheduling integrations
- Full analytics redesign
- Recreating the whole LeadZam product

### Trade-offs

Mock data enables a complete interaction demo within the assignment window. The prototype uses a compact table instead of a more complex board because it keeps the scope focused and works well for search/filter use cases. Metrics are illustrative and should not be interpreted as business results.

## Validation plan before production

1. Observe 5–7 sales users adding, searching, qualifying, and following up leads.
2. Measure time-to-find a lead, add-lead completion, filter-reset rate, and missed follow-ups.
3. Confirm field requirements, lead stage definitions, and permission rules with the product team.
4. Test responsive layout and keyboard/screen-reader flows.
5. Run a usability test against the current workflow and this prototype before release.

## AI usage notes

Draft honestly based on your actual work before submission:
- **Tools used:** ChatGPT for planning, audit structure, and code assistance (edit this to reflect the tools actually used).
- **How AI helped:** It helped scaffold a focused React/TypeScript interaction model and organize documentation.
- **One suggestion changed/rejected:** The implementation intentionally avoids building a large CRM or backend; the assignment asks for one high-impact area and a working frontend prototype.
- **Personally verified:** Before submission, run the app, test add-lead validation, search, filters, status updates, CSV export, responsive behavior, and inspect the code. Add any other checks you actually perform.

## Before submitting

- [ ] Personally explore the public site and, if possible, the authenticated app.
- [ ] Replace audit hypotheses with observed issues and add real screenshots.
- [ ] Create a Figma file using `docs/FIGMA-SPEC.md`, then add its real share link.
- [ ] Run `npm install`, `npm run dev`, and `npm run build`.
- [ ] Push meaningful incremental commits to your own GitHub repository.
- [ ] Record the 3–5 minute walkthrough and update this README with the actual links.
- [ ] Remove any claims you have not personally verified.
