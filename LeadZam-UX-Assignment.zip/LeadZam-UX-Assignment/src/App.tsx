import { useMemo, useState, type FormEvent } from 'react'
import {
  Activity, ArrowDownUp, Bell, CalendarClock, Check, ChevronDown, ChevronLeft,
  ChevronRight, CircleHelp, Command, Download, Filter, LayoutDashboard, LifeBuoy,
  ListFilter, Menu, MessageCircle, MoreHorizontal, Plus, Search, Settings2,
  SlidersHorizontal, Sparkles, Target, Users, X, Zap
} from 'lucide-react'

type LeadStatus = 'New' | 'Contacted' | 'Qualified' | 'Won' | 'Lost'
type Lead = {
  id: number; name: string; company: string; email: string; phone: string;
  source: string; status: LeadStatus; owner: string; initials: string;
  color: string; created: string; value: number; next: string
}
const initialLeads: Lead[] = [
  {id:1,name:'Aarav Mehta',company:'Northstar Learning',email:'aarav@northstar.example',phone:'+91 98765 43210',source:'Meta Ads',status:'New',owner:'Priya Sharma',initials:'PS',color:'violet',created:'Today, 10:42 AM',value:85000,next:'Call today'},
  {id:2,name:'Ananya Kapoor',company:'BrightPath Academy',email:'ananya@brightpath.example',phone:'+91 98111 22233',source:'Website',status:'Contacted',owner:'Rahul Verma',initials:'RV',color:'blue',created:'Today, 9:18 AM',value:42000,next:'Follow up tomorrow'},
  {id:3,name:'Kabir Singh',company:'Orbit EdTech',email:'kabir@orbit.example',phone:'+91 98989 12121',source:'Google Ads',status:'Qualified',owner:'Priya Sharma',initials:'PS',color:'violet',created:'Yesterday',value:120000,next:'Demo · 3:30 PM'},
  {id:4,name:'Diya Iyer',company:'Maple Skills',email:'diya@maple.example',phone:'+91 98220 44000',source:'WhatsApp',status:'New',owner:'Amit Joshi',initials:'AJ',color:'orange',created:'Yesterday',value:36000,next:'No follow-up set'},
  {id:5,name:'Reyansh Gupta',company:'Summit Tutorials',email:'reyansh@summit.example',phone:'+91 97654 32109',source:'CSV Import',status:'Won',owner:'Rahul Verma',initials:'RV',color:'blue',created:'18 Oct 2026',value:96000,next:'Closed won'},
  {id:6,name:'Sara Khan',company:'Pioneer Classes',email:'sara@pioneer.example',phone:'+91 98100 77889',source:'Meta Ads',status:'Contacted',owner:'Amit Joshi',initials:'AJ',color:'orange',created:'18 Oct 2026',value:54000,next:'Call today'},
  {id:7,name:'Ishaan Rao',company:'SkillSpring',email:'ishaan@skillspring.example',phone:'+91 99001 12345',source:'Google Ads',status:'Lost',owner:'Priya Sharma',initials:'PS',color:'violet',created:'17 Oct 2026',value:28000,next:'Closed lost'},
]
const statusClass: Record<LeadStatus,string> = {New:'new',Contacted:'contacted',Qualified:'qualified',Won:'won',Lost:'lost'}
const currency = (n:number) => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0}).format(n)

function App() {
  const [leads,setLeads] = useState<Lead[]>(initialLeads)
  const [query,setQuery] = useState('')
  const [status,setStatus] = useState('All statuses')
  const [source,setSource] = useState('All sources')
  const [activeTab,setActiveTab] = useState('All leads')
  const [showAdd,setShowAdd] = useState(false)
  const [showFilters,setShowFilters] = useState(false)
  const [selected,setSelected] = useState<Lead|null>(null)
  const [toast,setToast] = useState('')
  const [mobileNav,setMobileNav] = useState(false)
  const [formError,setFormError] = useState('')
  const [form,setForm] = useState({name:'',company:'',email:'',source:'Meta Ads',owner:'Priya Sharma'})
  const filtered = useMemo(() => leads.filter(l => {
    const q = query.toLowerCase()
    const matchesQuery = !q || [l.name,l.company,l.email,l.source].some(v=>v.toLowerCase().includes(q))
    const matchesStatus = status === 'All statuses' || l.status === status
    const matchesSource = source === 'All sources' || l.source === source
    const matchesTab = activeTab === 'All leads' || (activeTab === 'Needs follow-up' ? l.next.toLowerCase().includes('today') || l.next.toLowerCase().includes('no follow-up') : l.status === 'New')
    return matchesQuery && matchesStatus && matchesSource && matchesTab
  }),[leads,query,status,source,activeTab])
  const notify = (message:string) => { setToast(message); window.setTimeout(()=>setToast(''),3000) }
  const addLead = (e:FormEvent) => {
    e.preventDefault()
    if (!form.name.trim() || !form.email.trim()) { setFormError('Add a lead name and email to continue.'); return }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) { setFormError('Enter a valid email address.'); return }
    const name = form.name.trim()
    const lead:Lead = {id:Date.now(),name,company:form.company.trim()||'Company not provided',email:form.email.trim(),phone:'Not provided',source:form.source,status:'New',owner:form.owner,initials:form.owner.split(' ').map(s=>s[0]).join('').slice(0,2).toUpperCase(),color:'violet',created:'Just now',value:0,next:'No follow-up set'}
    setLeads(prev=>[lead,...prev]); setShowAdd(false); setForm({name:'',company:'',email:'',source:'Meta Ads',owner:'Priya Sharma'}); setFormError(''); setQuery('')
    notify(`${name} added to your leads`)
  }
  const changeStatus = (lead:Lead,next:LeadStatus) => {
    setLeads(prev=>prev.map(l=>l.id===lead.id?{...l,status:next}:l))
    if (selected) setSelected({...selected,status:next})
    notify(`${lead.name}'s status updated to ${next}`)
  }
  const exportCsv = () => {
    const rows = [['Name','Company','Email','Source','Status','Owner'],...filtered.map(l=>[l.name,l.company,l.email,l.source,l.status,l.owner])]
    const csv = rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}))
    const a = document.createElement('a'); a.href=url; a.download='leadzam-leads.csv'; a.click(); URL.revokeObjectURL(url)
    notify('CSV export prepared')
  }
  const resetFilters = () => {setQuery('');setStatus('All statuses');setSource('All sources');setActiveTab('All leads')}
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav?'sidebar-open':''}`}>
      <div className="brand"><div className="brand-mark"><Zap size={19} fill="currentColor"/></div><span>leadzam</span><button className="mobile-close icon-button" onClick={()=>setMobileNav(false)} aria-label="Close menu"><X size={18}/></button></div>
      <div className="workspace"><div className="workspace-avatar">N</div><div className="workspace-copy"><strong>Northstar Academy</strong><span>Growth workspace</span></div><ChevronDown size={15}/></div>
      <div className="nav-label">WORKSPACE</div>
      <nav className="nav-list">
        <button className="nav-item"><LayoutDashboard size={17}/> Overview</button>
        <button className="nav-item active"><Users size={17}/> Leads <span className="nav-count">{leads.length}</span></button>
        <button className="nav-item"><CalendarClock size={17}/> Follow-ups <span className="nav-dot"/></button>
        <button className="nav-item"><MessageCircle size={17}/> WhatsApp</button>
        <button className="nav-item"><Activity size={17}/> Campaign analytics</button>
      </nav>
      <div className="nav-label second-label">MANAGE</div>
      <nav className="nav-list">
        <button className="nav-item"><Target size={17}/> Lead stages</button>
        <button className="nav-item"><Users size={17}/> Team members</button>
        <button className="nav-item"><Settings2 size={17}/> Settings</button>
      </nav>
      <div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><LifeBuoy size={17}/></div><strong>Need a hand?</strong><p>Explore tips to get more from LeadZam.</p><button onClick={()=>notify('Help centre would open in the full product')}>Visit help centre <ChevronRight size={14}/></button></div><div className="profile"><div className="profile-avatar">PS</div><div className="profile-copy"><strong>Priya Sharma</strong><span>Admin</span></div><MoreHorizontal size={18}/></div></div>
    </aside>
    {mobileNav && <button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Close navigation"/>}
    <main className="main">
      <header className="topbar"><button className="mobile-menu icon-button" onClick={()=>setMobileNav(true)} aria-label="Open menu"><Menu size={20}/></button><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14}/><strong>Leads</strong></div><div className="top-actions"><div className="command-search"><Search size={15}/><span>Quick search</span><kbd>⌘ K</kbd></div><button className="icon-button notification" aria-label="Notifications" onClick={()=>notify('You’re all caught up')}><Bell size={18}/><i/></button><div className="top-avatar">PS</div></div></header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-dot"/> SALES WORKSPACE</div><h1>Leads</h1><p>Manage your prospects and keep every opportunity moving.</p></div><div className="heading-actions"><button className="button button-secondary" onClick={exportCsv}><Download size={16}/> Export</button><button className="button button-primary" onClick={()=>{setShowAdd(true);setFormError('')}}><Plus size={17}/> Add lead</button></div></div>
        <section className="metrics">
          <div className="metric-card"><div className="metric-top"><span>Total leads</span><span className="metric-icon purple"><Users size={17}/></span></div><div className="metric-value">{leads.length.toLocaleString('en-IN')}</div><div className="metric-foot"><span className="trend">↑ 12.8%</span><span>vs. last month</span></div></div>
          <div className="metric-card"><div className="metric-top"><span>Needs follow-up</span><span className="metric-icon amber"><CalendarClock size={17}/></span></div><div className="metric-value">{leads.filter(l=>l.next.toLowerCase().includes('today')||l.next.toLowerCase().includes('no follow-up')).length}</div><div className="metric-foot"><span className="foot-muted">Keep your pipeline moving</span></div></div>
          <div className="metric-card"><div className="metric-top"><span>Qualified leads</span><span className="metric-icon green"><Target size={17}/></span></div><div className="metric-value">{leads.filter(l=>l.status==='Qualified').length}</div><div className="metric-foot"><span className="trend">↑ 2</span><span>this week</span></div></div>
          <div className="metric-card"><div className="metric-top"><span>Pipeline value</span><span className="metric-icon blue"><Activity size={17}/></span></div><div className="metric-value">{currency(leads.filter(l=>!['Won','Lost'].includes(l.status)).reduce((sum,l)=>sum+l.value,0))}</div><div className="metric-foot"><span className="foot-muted">Open opportunities</span></div></div>
        </section>
        <section className="lead-panel">
          <div className="panel-heading"><div><h2>Lead directory</h2><p>One clear place to search, qualify, and act on leads.</p></div><button className="button button-quiet" onClick={()=>notify('Saved view feature is a prototype placeholder')}><SlidersHorizontal size={15}/> Customize view</button></div>
          <div className="tabs" role="tablist" aria-label="Lead views">{['All leads','New leads','Needs follow-up'].map(t=><button role="tab" aria-selected={activeTab===t} className={`tab ${activeTab===t?'tab-active':''}`} onClick={()=>setActiveTab(t)} key={t}>{t}{t==='All leads'&&<span>{leads.length}</span>}</button>)}</div>
          <div className="toolbar"><label className="search-input"><Search size={16}/><input aria-label="Search leads" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search name, company, email…"/>{query&&<button onClick={()=>setQuery('')} aria-label="Clear search"><X size={14}/></button>}</label><div className="toolbar-actions"><button className={`button button-secondary filter-button ${showFilters?'filter-active':''}`} onClick={()=>setShowFilters(v=>!v)}><Filter size={15}/> Filters {(status!=='All statuses'||source!=='All sources')&&<span className="filter-count">•</span>}</button><button className="icon-button sort-button" aria-label="Sort leads" onClick={()=>{setLeads(prev=>[...prev].reverse());notify('Lead order changed')}}><ArrowDownUp size={16}/></button></div></div>
          {showFilters&&<div className="filter-row"><label>Status<select value={status} onChange={e=>setStatus(e.target.value)}><option>All statuses</option>{(['New','Contacted','Qualified','Won','Lost'] as LeadStatus[]).map(s=><option key={s}>{s}</option>)}</select></label><label>Source<select value={source} onChange={e=>setSource(e.target.value)}><option>All sources</option>{['Meta Ads','Google Ads','Website','WhatsApp','CSV Import'].map(s=><option key={s}>{s}</option>)}</select></label><button className="text-button" onClick={resetFilters}>Clear filters</button></div>}
          <div className="table-wrap"><table><thead><tr><th><input type="checkbox" aria-label="Select all leads" onChange={()=>notify('Bulk selection is a prototype placeholder')}/></th><th>LEAD <button className="th-sort" aria-label="Sort by lead"><ArrowDownUp size={12}/></button></th><th>SOURCE</th><th>STATUS</th><th>OWNER</th><th>CREATED</th><th><span className="sr-only">Actions</span></th></tr></thead><tbody>
            {filtered.map(lead=><tr key={lead.id}><td><input type="checkbox" aria-label={`Select ${lead.name}`} onChange={()=>notify(`${lead.name} selected`)}/></td><td><button className="lead-person" onClick={()=>setSelected(lead)}><span className={`lead-avatar ${lead.color}`}>{lead.name.split(' ').map(n=>n[0]).join('').slice(0,2)}</span><span className="lead-person-copy"><strong>{lead.name}</strong><small>{lead.company}</small></span></button></td><td><span className="source-label"><span className={`source-dot ${lead.source.toLowerCase().replace(' ','-')}`}/>{lead.source}</span></td><td><span className={`status-pill ${statusClass[lead.status]}`}><i/>{lead.status}</span></td><td><span className="owner"><span className={`owner-avatar ${lead.color}`}>{lead.initials}</span>{lead.owner}</span></td><td className="date-cell">{lead.created}</td><td><button className="icon-button row-more" onClick={()=>setSelected(lead)} aria-label={`More actions for ${lead.name}`}><MoreHorizontal size={18}/></button></td></tr>)}
          </tbody></table>
          {filtered.length===0&&<div className="empty-state"><div className="empty-icon"><ListFilter size={22}/></div><h3>No leads match those filters</h3><p>Try another search or clear filters to see all leads.</p><button className="button button-secondary" onClick={resetFilters}>Clear filters</button></div>}
          </div>
          <div className="table-footer"><span>Showing <strong>{filtered.length?1:0}–{filtered.length}</strong> of <strong>{filtered.length}</strong> results</span><div className="pagination"><button className="icon-button" disabled aria-label="Previous page"><ChevronLeft size={16}/></button><button className="page-number">1</button><button className="icon-button" disabled aria-label="Next page"><ChevronRight size={16}/></button></div></div>
        </section>
        <div className="prototype-note"><Sparkles size={15}/><span><strong>Prototype workspace</strong> · All records are fictional sample data. Changes stay in this browser session only.</span><button onClick={()=>notify('Prototype notes: mock data, no backend connection.')}>Details</button></div>
      </div>
      <footer className="footer"><span>© 2026 LeadZam · UX concept prototype</span><span><CircleHelp size={14}/> Help & support</span></footer>
    </main>
    {showAdd&&<div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setShowAdd(false)}}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="add-title"><div className="modal-header"><div><div className="modal-kicker">LEAD DIRECTORY</div><h2 id="add-title">Add a new lead</h2><p>Capture the details you need to start a conversation.</p></div><button className="icon-button" onClick={()=>setShowAdd(false)} aria-label="Close dialog"><X size={19}/></button></div><form onSubmit={addLead} noValidate><div className="form-grid"><label className="field full">Lead name <span>*</span><input autoFocus value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Aanya Mehta" aria-required="true"/></label><label className="field full">Company<input value={form.company} onChange={e=>setForm({...form,company:e.target.value})} placeholder="Company or organisation"/></label><label className="field full">Email address <span>*</span><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="name@company.com" aria-required="true"/></label><label className="field">Lead source<select value={form.source} onChange={e=>setForm({...form,source:e.target.value})}>{['Meta Ads','Google Ads','Website','WhatsApp','CSV Import'].map(s=><option key={s}>{s}</option>)}</select></label><label className="field">Assign owner<select value={form.owner} onChange={e=>setForm({...form,owner:e.target.value})}>{['Priya Sharma','Rahul Verma','Amit Joshi'].map(s=><option key={s}>{s}</option>)}</select></label></div>{formError&&<div className="form-error" role="alert"><X size={15}/>{formError}</div>}<div className="form-hint"><span>*</span> Required fields. You can add more details later.</div><div className="modal-actions"><button type="button" className="button button-secondary" onClick={()=>setShowAdd(false)}>Cancel</button><button type="submit" className="button button-primary"><Plus size={16}/> Add lead</button></div></form></section></div>}
    {selected&&<div className="drawer-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)setSelected(null)}}><aside className="detail-drawer" role="dialog" aria-modal="true" aria-labelledby="detail-title"><div className="drawer-header"><span>LEAD DETAILS</span><button className="icon-button" onClick={()=>setSelected(null)} aria-label="Close details"><X size={19}/></button></div><div className="detail-profile"><span className={`detail-avatar ${selected.color}`}>{selected.name.split(' ').map(n=>n[0]).join('').slice(0,2)}</span><h2 id="detail-title">{selected.name}</h2><p>{selected.company}</p><span className={`status-pill ${statusClass[selected.status]}`}><i/>{selected.status}</span></div><div className="detail-section"><h3>Contact information</h3><div className="detail-line"><span>Email</span><strong>{selected.email}</strong></div><div className="detail-line"><span>Phone</span><strong>{selected.phone}</strong></div><div className="detail-line"><span>Source</span><strong>{selected.source}</strong></div><div className="detail-line"><span>Lead owner</span><strong>{selected.owner}</strong></div><div className="detail-line"><span>Created</span><strong>{selected.created}</strong></div></div><div className="detail-section"><h3>Update lead stage</h3><label className="field">Current status<select value={selected.status} onChange={e=>changeStatus(selected,e.target.value as LeadStatus)}>{(['New','Contacted','Qualified','Won','Lost'] as LeadStatus[]).map(s=><option key={s}>{s}</option>)}</select></label></div><div className="detail-section followup-card"><div className="followup-icon"><CalendarClock size={17}/></div><div><strong>Next action</strong><p>{selected.next}</p></div><button className="text-button" onClick={()=>notify('Follow-up scheduling is a planned prototype enhancement')}>Schedule</button></div><button className="button button-primary drawer-primary" onClick={()=>{setSelected(null);notify('Call action is a prototype placeholder')}}><MessageCircle size={16}/> Log an activity</button></aside></div>}
    {toast&&<div className="toast" role="status"><span className="toast-check"><Check size={15}/></span>{toast}<button onClick={()=>setToast('')} aria-label="Dismiss notification"><X size={14}/></button></div>}
  </div>
}
export default App
